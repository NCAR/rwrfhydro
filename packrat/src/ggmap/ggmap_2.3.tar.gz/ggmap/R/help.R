#' @import proto scales RgoogleMaps png plyr reshape2 grid rjson mapproj
#' @docType package
#' @name ggmap
#' @aliases ggmap package-ggmap
NULL